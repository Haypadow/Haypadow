
        module.exports = {
            bot: {
                token: "ODY2NzQ5MTQ5MDg4MTg2NDI4.YPXFDA.u57IhHcud_Lt834bI8niAe4bYAg",
                prefix: "!",
                owners: ["678379354945880065"],
                mongourl: "mongodb+srv://admin:admin@cluster0.yujhb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
                servers: {
                    token: "ODY2NzQ5MTQ5MDg4MTg2NDI4.YPXFDA.u57IhHcud_Lt834bI8niAe4bYAg",
                    prefix: "!"
                }
            },
        
            website: {
                callback: "https://topgg.h-a-ya.repl.co/callback",
                secret: "WZG-uZLAzMw3T_eDcKIy1sYeX_ajMv5C",
                clientID: "866749149088186428", // Bot client id.
                tags: [ "Moderation", "Fun", "Minecraft","Economy","Guard","NSFW","Anime","Invite","Music","Logging", "Web Dashboard", "Reddit", "Youtube", "Twitch", "Crypto", "Leveling", "Game", "Roleplay", "Utility"],
                languages: [
                    { flag: 'gb', code: 'en', name: 'English' },
                    { flag: 'tr', code: 'tr', name: 'Türkçe' },
                    { flag: 'de', code: 'de', name: 'Deutsch' }
                ],
                servers: {
                    tags: [
                    {
                        icon: "fal fa-code",
                        name: "Development"
                    },
                    {
                        icon: "fal fa-play",
                        name: "Stream"
                    },
                    {
                        icon: "fal fa-camera",
                        name: "Media"
                    },
                    {
                        icon: 'fal fa-building',
                        name: 'Company'
                    },
                    {
                        icon: 'fal fa-gamepad',
                        name: 'Game'
                    },
                    {
                        icon: 'fal fa-icons',
                        name: 'Emoji'
                    },
                    {
                        icon: 'fal fa-robot',
                        name: 'Bot List'
                    },
                    {
                        icon: 'fal fa-server',
                        name: 'Server List'
                    },
                    {
                        icon: 'fal fa-moon-stars',
                        name: 'Turkish'
                    },
                    {
                        icon: 'fab fa-discord',
                        name: 'Support'
                    },
                    {
                        icon: 'fal fa-volume',
                        name: 'Sound'
                    },
                    {
                        icon: 'fal fa-comments',
                        name: 'Chatting'
                    },
                    {
                        icon: 'fal fa-lips',
                        name: 'NSFW'
                    },
                    {
                      icon: "fal fa-comment-slash",
                      name: "Challange"
                    },
                    {
                      icon: "fal fa-hand-rock",
                      name: "Protest"
                    },
                    {
                      icon: "fal fa-headphones-alt",
                      name: "Roleplay"
                    },
                    {
                      icon: "fal fa-grin-alt",
                      name: "Meme"
                    },
                    {
                      icon: "fal fa-shopping-cart",
                      name: "Shop"
                    },
                    {
                      icon: "fal fa-desktop",
                      name: "Technology"
                    },
                    {
                      icon: "fal fa-laugh",
                      name: "Fun"
                    },
                    {
                      icon: "fal fa-share-alt",
                      name: "Social"
                    },
                    {
                      icon: "fal fa-laptop",
                      name: "E-Spor"
                    },
                    {
                      icon: 'fal fa-palette',
                      name: 'Design'
                    },
                    {
                      icon: 'fal fa-users',
                      name: 'Community'
                    }
                    ]                
                }
            },
        
            server: {
                id: "",
                invite: "https://discord.gg/z7dBzygse4",
                roles: {
                    administrator: "",
                    moderator: "",
                    profile: {
                        sitecreator : "",
                        booster: "",
                        sponsor: "",
                        supporter: "",
                        partnerRole: ""
                    },
                    codeshare: {
                        javascript: "",
                        html: "",
                        substructure: "",
                        bdfd: "", // Bot Designer For Discord
                        fiveInvite: "",
                        tenInvite: "",
                        fifteenInvite: "",
                        twentyInvite: ""
                    },
                    botlist: {
                        developer: "",
                        certified_developer: "",
                        bot: "",
                        certified_bot: "",
                    }
                },
                channels: {
                    codelog: "",
                    login: "866538234305052722",
                    webstatus: "",
                    uptimelog: "",
                    botlog: "",
                    votes: ""
                }
            }
        
        
        }